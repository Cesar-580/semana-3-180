module.exports = {
    'secret': 'key-super-secret',
};